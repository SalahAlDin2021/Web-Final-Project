<?php include "parts/_header.php" ?>
<main>
    <h2>Students List</h2>
    
    <img width="100%" src="assignment-screenshots/02_students.png" />
</main>
<aside>
    <h2>Distinguished Students</h2>
    <p>
        Student Ali Ahmad from Birzeit is very special and he is looking for training in Computer Science...
    </p>
</aside>
<?php include "parts/_footer.php" ?>

