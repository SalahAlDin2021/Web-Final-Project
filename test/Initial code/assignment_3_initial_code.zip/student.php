<?php include "parts/_header.php" ?>
<main>
    <h2>Student 1 Name</h2>
    
    <img width="100%" src="assignment-screenshots/03_student.png" />
</main>
<aside>
    <h2>Similar Students</h2>
    <p>
        A student or 2 students with same major
    </p>
</aside>
<?php include "parts/_footer.php" ?>

