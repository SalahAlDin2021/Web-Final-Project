        <footer>
            <img src="images/my-photo.png" alt="My Photo" />
            <div>
                Copyright: &copy; [Student ID] - [Student name]
            </div>
            <div>
                Tel: <a href="tel:+970561234567">+970 56 1234567</a>
                Email: <a href="mailto:info@student-training.com">info@student-training.com</a>
            </div>
        </footer>
    </body>
</html>
