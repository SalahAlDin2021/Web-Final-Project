<!DocType html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="css/layout.css" />
        <link rel="stylesheet" href="css/website.css" />
        <title>Student Training</title>
    </head>
    <body>
        <header>
            <img src="images/training.png" alt="logo" />
            <h1>Student Training</h1>
            <a href="index.php">Login</a>
            <nav>
                <a href="index.php">Home</a>
                <a href="students.php">Students List</a>
                <a href="companies.php">Companies List</a>
            </nav>
        </header>
