<?php include "parts/_header.php" ?>
<main>
    <h2>Add Company</h2>
    
    <img width="100%" src="assignment-screenshots/07_add-company.png" />
</main>
<aside>
    <h2>Help</h2>
    <p>
        Add company and positions details so that students can find you...
    </p>
</aside>
<?php include "parts/_footer.php" ?>

