<?php include "parts/_header.php" ?>
<main>
    <h2>Company 1 Name</h2>
    
    <img width="100%" src="assignment-screenshots/06_company.png" />
</main>
<aside>
    <h2>Similar Companies</h2>
    <p>
        Another companies in same location looking for students...
    </p>
</aside>
<?php include "parts/_footer.php" ?>

