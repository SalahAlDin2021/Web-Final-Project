<?php include "parts/_header.php" ?>
<main>
    <h2>Login</h2>
    
    <img width="100%" src="assignment-screenshots/01_index.png" />
</main>
<aside>
    <h2>Aside</h2>
    <p>
        The aside will have information related to the current page or ads.
    </p>
</aside>
<?php include "parts/_footer.php" ?>

