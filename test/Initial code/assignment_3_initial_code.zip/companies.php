<?php include "parts/_header.php" ?>
<main>
    <h2>Companies List</h2>
    
    <img width="100%" src="assignment-screenshots/05_companies.png" />
</main>
<aside>
    <h2>Highlighted Company</h2>
    <p>
        This will contain a random special company details...
    </p>
</aside>
<?php include "parts/_footer.php" ?>

