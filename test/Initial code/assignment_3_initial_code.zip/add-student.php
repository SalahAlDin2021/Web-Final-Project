<?php include "parts/_header.php" ?>
<main>
    <h2>Add Student</h2>
    
    <img width="100%" src="assignment-screenshots/04_add-student.png" />
</main>
<aside>
    <h2>Help</h2>
    <p>
        Add your student details including projects and interests so that companies can select you...
    </p>
</aside>
<?php include "parts/_footer.php" ?>

